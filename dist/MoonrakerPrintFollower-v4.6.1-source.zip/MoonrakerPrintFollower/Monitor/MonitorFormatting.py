"""Pure Monitor projections/parsers. No Qt, networking, timers or mutable owners."""
from __future__ import annotations

import ast
from collections.abc import Mapping
from datetime import datetime, timedelta
import math
import re

from .MonitorPermissions import REASON_DETAIL, R_UNKNOWN, Verdict, can_pause, can_resume

from ..Geometry.Polygons import point_in_polygon


def result(payload):
    """The 'result' field of a Moonraker reply, falling back to the
    payload itself; {} when there is no mapping at all."""
    return payload.get("result", payload) if isinstance(payload, Mapping) else {}


def factor_percent(value) -> str:
    """A speed/flow factor as a percentage, or '—' when the printer did
    not report one (empty snapshot, reconnect, unsupported Klipper)."""
    factor = number(value, None)
    return "—" if factor is None else f"{round(min(500, max(0.01, factor)) * 100)}%"


def number(value, default=0.0):
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError, OverflowError): return default


def friendly(name):
    if name == "extruder": return "Hotend"
    match = re.fullmatch(r"extruder(\d+)", name)
    if match: return f"Hotend {int(match.group(1)) + 1}"
    if name == "heater_bed": return "Bed"
    if name == "fan": return "Part fan"
    return name.split(" ", 1)[-1].replace("_", " ").strip().capitalize()


def chart_label(name):
    """The chart/pane label: friendly(), with the family kept for fan
    objects so a temperature_fan's reading cannot be mistaken for a
    heater of the same suffix — and the host's own temperature marked
    "(host)", because a temperature_host and a temperature_sensor with
    the same suffix (a raspberry_pi pair) otherwise render
    as the SAME name twice in the temperature lists."""
    label = friendly(name)
    if object_kind(name) == "fan":
        return label + " (fan)"
    if str(name).lower().startswith("temperature_host "):
        return label + " (host)"
    return label


# One classification policy for Klipper printer objects. MonitorData uses it
# to decide what to query; the controllers and formatting use it to decide
# what to project. Adding a new object family means editing these tables only.
FAN_OBJECT_PREFIXES = ("fan_generic ", "heater_fan ", "controller_fan ", "temperature_fan ")


def fan_writable(name: str) -> bool:
    """Whether SET_FAN_SPEED actually controls this fan object. Klipper's
    controller_fan, temperature_fan and heater_fan are
    temperature-regulated — the command either never sticks or is not
    registered at all (live reports: controller_fan1 and
    hotend_fan) — so their rows render read-only."""
    lower = str(name).lower()
    if lower == "fan":
        return True
    return lower.startswith(("fan_generic ",))
LED_OBJECT_PREFIXES = ("neopixel ", "dotstar ", "led ", "pca9533 ", "pca9632 ")
PWM_OBJECT_PREFIXES = ("output_pin ",)
TEMPERATURE_OBJECT_PREFIXES = ("heater_generic ", "temperature_", "bme280 ", "htu21d ", "sht3x ", "lm75 ")
FILAMENT_OBJECT_PREFIXES = ("filament_switch_sensor ", "filament_motion_sensor ")
MCU_OBJECT_PREFIXES = ("mcu ",)

# pause_resume rides the CORE lane (4.3.0) — it must NOT appear here:
# the aux merge would overwrite the core value one slow interval later.
_SYSTEM_OBJECTS = {"heater_bed", "fan", "exclude_object", "system_stats", "webhooks", "mcu",
                   "configfile", "toolhead", "quad_gantry_level", "bed_mesh", "display_status"}


def object_kind(name):
    """Classify a Klipper printer object into one shared projection kind."""
    lower = str(name or "").lower()
    if lower in _SYSTEM_OBJECTS or re.fullmatch(r"extruder\d*", lower):
        return "system"
    if lower.startswith("gcode_macro "):
        return "macro"
    if lower.startswith(FAN_OBJECT_PREFIXES):
        return "fan"
    if lower.startswith(LED_OBJECT_PREFIXES):
        return "led"
    if lower.startswith(PWM_OBJECT_PREFIXES):
        return "pwm"
    if lower.startswith(TEMPERATURE_OBJECT_PREFIXES):
        return "temperature"
    if lower.startswith(FILAMENT_OBJECT_PREFIXES):
        return "filament"
    if lower.startswith(MCU_OBJECT_PREFIXES):
        return "mcu"
    return ""


def wanted_object(name):
    """Whether MonitorData should query this object's auxiliary state."""
    return object_kind(name) in {"system", "fan", "led", "pwm", "temperature", "filament", "mcu"}


def chart_temperature_objects(auxiliary):
    """Temperature-bearing objects for the chart and the pane's list.

    Heaters and temperature sensors chart unconditionally. Fan objects
    (``temperature_fan``) chart only when no other charted object reads
    the same sensor — equal readings at the same tick — because the
    fan's temperature is worth plotting only when it is the only window
    onto that sensor. The pane's temperature list and the chart share
    this predicate so the two can never disagree.
    """
    readings = {}
    for name, value in auxiliary.items():
        if not isinstance(value, Mapping):
            continue
        kind = object_kind(name)
        if kind == "system":
            lower = str(name).lower()
            if lower != "heater_bed" and not re.fullmatch(r"extruder\d*", lower):
                continue
        elif kind not in ("temperature", "fan"):
            continue
        temperature = number(value.get("temperature"), None)
        if temperature is None:
            continue
        readings[str(name)] = temperature
    for name, reading in list(readings.items()):
        if object_kind(name) != "fan":
            continue
        if any(object_kind(other) != "fan" and abs(reading - other_reading) <= 0.01
               for other, other_reading in readings.items() if other != name):
            del readings[name]
    return readings


def preview_eta_text(snapshot, physical):
    """The strip's middle-slot ETA: the same remaining/finish pair the
    Monitor's rows show, composed for one narrow slot. 'Paused' while
    paused; '—' when there is nothing to say (no print, no estimate)."""
    stats = snapshot.get("print_stats") or {}
    sd = snapshot.get("virtual_sdcard") or {}
    state = str(stats.get("state") or "")
    if state == "paused":
        return "Paused"
    if state != "printing":
        return "—"
    remaining = getattr(physical, "layer_eta", None)
    if remaining is None:
        remaining = estimate_remaining(stats.get("print_duration"), sd.get("progress"), physical.estimated_time, physical.metadata_complete)
    if remaining is None:
        return "—"
    finish_dt = datetime.now().astimezone() + timedelta(seconds=remaining)
    finish = finish_dt.strftime("%H:%M")
    return f"{duration(remaining)} · ≈{finish}{day_offset_suffix(finish_dt)}"


def day_offset_suffix(finish_dt: datetime) -> str:
    """'+n' when the finish lands on a later day — the print crosses
    midnight (the live request: ~10:18 +1)."""
    offset = (finish_dt.date() - datetime.now().astimezone().date()).days
    return f" +{offset}" if offset > 0 else ""


def duration(seconds):
    hours, rest = divmod(max(0, int(round(number(seconds)))), 3600)
    minutes, seconds = divmod(rest, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def layer_readout(layer) -> str:
    """The preview card's current-layer cell: the HUMAN layer number
    from the PRINTER's observation (never the preview's selection),
    with the total when known — 'current/total' (the live ruling),
    the bare number without one, '—' while the resolver has no
    layer."""
    index = getattr(layer, "index", None)
    if index is None:
        return "—"
    total = getattr(layer, "total", None)
    return f"{index + 1}/{total}" if total is not None else str(index + 1)


def height_readout(layer) -> str:
    """The preview card's current-height cell: the printer's absolute
    Z with its unit, ALWAYS two decimals (the live ruling) — '—'
    while unresolvable."""
    height = getattr(layer, "height", None)
    return f"{height:.2f} mm" if height is not None else "—"


def print_job_caption(observation) -> str:
    """The print-job caption's state read (4.3.0): the STATE word
    mapped once — never a permission boolean, so a busy lane never
    reads as "Printing". Disconnected and unknown name themselves
    instead of lying "Idle" while the socket is down; the controls
    lock names itself so the dead action band keeps its context
    (the locked-case naming, F18). The lock wins over the job word —
    the Job section's own status row still shows the job state."""
    if observation is None:
        return ""
    if observation.connection != "yes":
        return "Disconnected" if observation.connection == "no" else "Printer state unknown"
    if observation.controls_locked:
        return "Locked"
    return {"printing": "Printing", "paused": "Paused"}.get(observation.state, "Idle")


def preview_temperature_pair(auxiliary):
    """The strip's fixed pair: hotend and bed, the Monitor's own
    labels and current→target form. target 0.0 means 'no setpoint /
    at rest' — the arrow is omitted. A missing or non-finite reading
    renders '—'; a 0.0 reading on a heater with no target is '—' too
    (a pre-first-sample heater reports 0.0 — Klipper's own
    not-measured convention). Per-heater staleness is not observable
    from object status — the strip's staleness rule is about the
    FEED, never about this pair."""
    aux = auxiliary or {}
    hotend_state = None
    bed_state = None
    for name, value in aux.items():
        if not isinstance(value, Mapping):
            continue
        lower = str(name).lower()
        if lower == "heater_bed":
            bed_state = value
        elif re.fullmatch(r"extruder\d*", lower) and hotend_state is None:
            hotend_state = value

    def cell(state):
        if not isinstance(state, Mapping):
            return "—"
        temperature = number(state.get("temperature"), None)
        target = number(state.get("target"), None)
        if temperature is None or temperature <= 0 and not (target or 0) > 0:
            return "—"
        if (target or 0) > 0:
            # The arrow form (the 2026-09-16 ruling): the
            # preview pair reads current → desired, like the Monitor.
            return f"{temperature:.1f} → {target:.1f} °C"
        return f"{temperature:.1f} °C"

    return cell(hotend_state), cell(bed_state)


def preview_block(auxiliary, observation, *, stamp, inactive=False):
    """The Preview value block (4.3.0): the slim per-poll carrier for
    the strip — the fixed hotend/bed pair, the pause/resume verdicts
    (with the policy's words for the tooltips) and the arrival stamp.
    The block is GENERIC on purpose: the 4.4.0 camera thumbnail and
    the marker's readouts reuse the same carrier. The stamp is taken
    at the aux landing (MonitorData's clock) and never re-stamped in
    transit — a republished block keeps its age, so the strip's
    staleness rule has a real clock. Absence is an explicit shape
    (the inactive flag + '—' cells), never an omitted key — the
    preview publish dict never removes a key."""
    pause_verdict = can_pause(observation) if observation is not None else Verdict("disabled", R_UNKNOWN)
    resume_verdict = can_resume(observation) if observation is not None else Verdict("disabled", R_UNKNOWN)
    hotend, bed = preview_temperature_pair(auxiliary)
    return {
        "stamp": float(stamp),
        "inactive": bool(inactive),
        "state": str(getattr(observation, "state", "") or ""),
        "hotend": hotend,
        "bed": bed,
        "canPause": pause_verdict.mode == "allowed",
        "canResume": resume_verdict.mode == "allowed",
        "pauseReason": pause_verdict.reason,
        "pauseReasonDetail": REASON_DETAIL.get(pause_verdict.reason, ""),
        "resumeReason": resume_verdict.reason,
        "resumeReasonDetail": REASON_DETAIL.get(resume_verdict.reason, ""),
        "busy": bool(getattr(observation, "busy", False)),
    }


def estimate_remaining(elapsed, progress, estimate, complete):
    elapsed, progress, estimate = max(0, number(elapsed)), max(0, min(1, number(progress))), number(estimate)
    # The by-file blend needs only a little progress signal and must
    # appear promptly: the unoptimised values are expected as
    # soon as Moonraker reports them on connect, not a minute into the
    # print (the old 60 s / 2% floor left the readout empty at start).
    by_file = max(0, elapsed / progress - elapsed) if progress >= 0.005 and elapsed >= 10 else None
    if estimate > 0:
        remaining = max(0, estimate - elapsed)
        if remaining > 0:
            if by_file is not None and 0.60 * estimate <= elapsed + by_file <= 1.75 * estimate:
                return 0.75 * remaining + 0.25 * by_file
            return remaining
        return by_file if by_file is not None else 0.0
    return by_file if complete else None


# How much of a downloaded gcode file's head the filament-total scan
# may read. Slicers write the ';Filament used:' declaration in the
# file's opening comments, so one bounded read of the head covers every
# real file; the bound keeps a hostile file with no such line (or no
# newlines) a bounded cost instead of a full-file scan. The scan runs
# once per downloaded file, never on a timer.
_FILAMENT_HEADER_SCAN_BYTES = 1024 * 1024


def filament_total_mm_from_gcode(data):
    """The slicer's declared total filament length (mm), parsed from the
    FIRST ';Filament used:' line of gcode header text.

    CuraEngine writes one comma-separated metre value per extruder on
    that line; the values are summed (Moonraker's own metadata parse
    read only the FIRST value until the v0.10 series, undercounting
    multi-extruder prints by the other materials' lengths). None when
    the file carries
    no such line — callers then keep Moonraker's metadata total, which
    is exactly today's behaviour. The unit is mm end-to-end: each value
    is in metres, so the sum is scaled by 1000.
    """
    marker = re.compile(rb";Filament\s+used\s*:", re.IGNORECASE)
    value = re.compile(rb"[0-9]*\.?[0-9]+")
    for raw in bytes(data or b"").splitlines():
        stripped = raw.lstrip()
        if not stripped.startswith(b";") or marker.search(stripped) is None:
            continue
        # Every value on the FIRST declaration line must be a finite
        # length: a hostile token (an overflowing digit run) makes the
        # whole line untrustworthy, and a line with no usable values
        # carries no total at all. None either way — the caller then
        # keeps the Moonraker metadata total.
        values = [number(token, None) for token in value.findall(stripped)]
        if not values or any(parsed is None for parsed in values):
            return None
        total = sum(values)
        if not math.isfinite(total):
            return None
        return total * 1000.0
    return None


def filament_total_mm_from_file(path, limit=_FILAMENT_HEADER_SCAN_BYTES):
    """The header's total filament (mm) from a downloaded gcode file.

    Only the file's head is ever read (``limit`` bytes): the slicer's
    header sits at the very top of the file, so the FIRST
    ';Filament used:' line of the whole file is inside the head for
    every real slicer. A line truncated by the limit is ignored — a
    partial value must not masquerade as the total. Missing or
    unreadable files yield None (the Moonraker metadata fallback).
    """
    try:
        with open(path, "rb") as handle:
            data = handle.read(limit + 1)
    except OSError:
        return None
    if len(data) > limit:
        # The file continues past the window: drop the possibly partial
        # final line before parsing.
        cut = data.rfind(b"\n")
        data = data[:cut] if cut >= 0 else b""
    return filament_total_mm_from_gcode(data)


def _flow_text(flow) -> str:
    """The %.1f form with the negative-zero guard: a magnitude that
    rounds to zero renders without the sign (round-then-clamp)."""
    text = f"{flow:.1f}"
    return "0.0" if text == "-0.0" else text


def filament_diameter(auxiliary):
    """The active extruder's filament_diameter from the configfile
    settings, or None. Klipper only creates extruder, extruder1..98
    sections (validation rejects any other name), so the exact-key
    lookup is safe; the predicate is the same one object_kind uses
    (a prefix sweep would also match [extruder_stepper]). settings
    holds the typed values with defaults applied — the raw strings
    live in config."""
    configfile = auxiliary.get("configfile") or {}
    settings = configfile.get("settings") or {}
    if not isinstance(settings, Mapping): return None
    tool = str((auxiliary.get("toolhead") or {}).get("extruder") or "extruder").lower()
    if not re.fullmatch(r"extruder\d*", tool): return None
    section = settings.get(tool)
    return number(section.get("filament_diameter"), None) if isinstance(section, Mapping) else None


def core_values(snapshot, physical, connected):
    stats = snapshot.core.get("print_stats") or {}
    sd = snapshot.core.get("virtual_sdcard") or {}
    move = snapshot.core.get("gcode_move") or {}
    motion = snapshot.core.get("motion_report") or {}
    info = stats.get("info") or {}
    state = str(stats.get("state") or "unknown")
    layer = physical.layer
    current, total = layer.index, layer.total
    layer_text = f"{current + 1} / {total}" if current is not None and total is not None else str(current + 1) if current is not None else f"— / {total}" if total else "—"
    eta, finish, basis = "—", "—", ""
    if state == "paused": eta = "Paused"
    elif state == "printing":
        # The layer-anchored estimate (index timing × observed speed)
        # wins when the coordinator computed one; the plain blend stays
        # the fallback and the UI shows which basis is active.
        remaining = getattr(physical, "layer_eta", None)
        basis = "index"
        if remaining is None:
            remaining = estimate_remaining(stats.get("print_duration"), sd.get("progress"), physical.estimated_time, physical.metadata_complete)
            basis = "blend"
        if remaining is not None:
            eta = duration(remaining)
            finish_dt = datetime.now().astimezone() + timedelta(seconds=remaining)
            finish = finish_dt.strftime("%a %H:%M" if remaining >= 72000 else "%H:%M") + day_offset_suffix(finish_dt)
    # How far through the CURRENT layer the file position is, from the
    # index's byte ranges (the nozzle's Z never moves within a layer,
    # so Z cannot express this). -1 without an index: the bar hides.
    layer_progress = getattr(physical, "layer_progress", None)
    if layer_progress is None:
        layer_progress = -1.0
    position = motion.get("live_position") or ()
    # Filament accounting (the request): Moonraker reports the
    # used length as a TOP-LEVEL print_stats field; Klipper's info dict
    # only ever holds the layer counters a slicer's SET_PRINT_STATS_INFO
    # wrote (current_layer/total_layer), never filament_used — the old
    # info-dict read matched no real poll. The info dict stays a
    # fallback for robustness. The slicer's total is the CLIENT's own
    # parse of the downloaded file's header (filament_total_mm_from_*)
    # in the coordinator snapshot (physical.filament_total): Moonraker's
    # metadata read only the first ';Filament used:' value of multi-
    # extruder prints until the v0.10 series, so the client-side sum is
    # preferred and the metadata total stays the fallback for files
    # never
    # downloaded. The monitor snapshot is the second home for legacy
    # callers.
    used_mm = number(stats.get("filament_used"), None)
    if used_mm is None:
        used_mm = number(info.get("filament_used"), None)
    total_mm = getattr(physical, "filament_total", None)
    if total_mm is None:
        total_mm = getattr(snapshot, "filament_total", None)
    filament_used = f"{used_mm / 1000.0:.2f} m" if used_mm is not None else "—"
    # Remaining is only a number while the measured used length still
    # fits under the declared total. Once used OVERTAKES total the
    # total is untrustworthy (Moonraker's metadata undercounts multi-
    # extruder prints) — the old clamp then stated a wrong estimate as
    # a confident "0.00 m" for the rest of the job; "—" is the honest
    # readout.
    filament_remaining = f"{max(0.0, total_mm - used_mm) / 1000.0:.2f} m" \
        if used_mm is not None and total_mm is not None and 0 <= used_mm <= total_mm else "—"
    # The motion rows (4.2.0): Velocity is Klipper's scalar speed
    # MAGNITUDE (live_velocity is never signed). Flow rate is the
    # COMMANDED volumetric flow — live_extruder_velocity × the
    # filament cross-section — signed, so a retraction reads
    # negative; the ROUNDED value never renders "-0.0" (round-then-
    # clamp, the panel's ruling — a pre-rounding clamp at 0.05
    # would have zeroed a genuinely small commanded flow, the
    # adversarial round's L6). Accel limit is the configured ceiling
    # (Klipper publishes no instantaneous acceleration), from the
    # aux poll's toolhead. "—" means a row's SOURCES have not
    # reported — motion_report absent, or the printer.cfg diameter
    # not resident yet for Flow rate (the discovery lane is its
    # only supplier); an idle CONNECTED printer reads 0.
    velocity = number(motion.get("live_velocity"), None)
    ev = number(motion.get("live_extruder_velocity"), None)
    # The existing test snapshots are bare core-only namespaces — the
    # auxiliary read must tolerate their absence (the ride-the-existing-
    # argument ruling) rather than force a churn across call sites.
    aux = getattr(snapshot, "auxiliary", None) or {}
    diameter = filament_diameter(aux)
    flow = None
    if ev is not None and diameter:
        flow = ev * math.pi * (diameter / 2.0) ** 2
    accel = number((aux.get("toolhead") or {}).get("max_accel"), None)
    return {
        "monitorState": state.capitalize() if connected else "Disconnected",
        "monitorFilename": str(stats.get("filename") or ""),
        "monitorProgress": max(0, min(100, round(number(sd.get("progress")) * 100, 2))),
        "monitorLayer": layer_text, "monitorLayerHeight": f"{layer.thickness:.3f} mm" if layer.thickness is not None else "—",
        "monitorLayerSource": getattr(layer, "source", ""),
        "monitorLayerProgress": layer_progress,
        "monitorElapsed": duration(stats.get("print_duration")), "monitorEta": eta, "monitorFinish": finish,
        "monitorEtaBasis": basis,
        "monitorSpeed": factor_percent(move.get("speed_factor")),
        "monitorFlow": factor_percent(move.get("extrude_factor")),
        "monitorPosition": f"X {number(position[0]):.1f}   Y {number(position[1]):.1f}   Z {number(position[2]):.2f}" if len(position) >= 3 else "—",
        # The collapsed strip's single-line form: single-space
        # separators — the wide form's triple spaces were sized for
        # the expanded row.
        "monitorPositionCompact": f"X {number(position[0]):.1f} Y {number(position[1]):.1f} Z {number(position[2]):.2f}" if len(position) >= 3 else "—",
        # The collapsed strip's per-axis cells (the live ruling):
        # each axis independent and fixed-width in the UI.
        "monitorPositionX": f"X {number(position[0]):.1f}" if len(position) >= 3 else "—",
        "monitorPositionY": f"Y {number(position[1]):.1f}" if len(position) >= 3 else "—",
        "monitorPositionZ": f"Z {number(position[2]):.2f}" if len(position) >= 3 else "—",
        "monitorVelocity": f"{velocity:.1f} mm/s" if velocity is not None else "—",
        "monitorFlowRate": f"{_flow_text(flow)} mm³/s" if flow is not None else "—",
        "monitorFlowDiameter": f"{diameter:.2f} mm" if diameter else "—",
        "monitorAccelLimit": f"{accel:.0f} mm/s²" if accel is not None else "—",
        "monitorMessage": str(stats.get("message") or ""),
        "filamentUsed": filament_used,
        "filamentRemaining": filament_remaining,
    }


def endstop_values(snapshot, connected=True):
    """The endstop readout: per-axis pin states, or a summary when
    nothing reported. The summary makes NO causal claim — an empty
    set also describes a sensorless-homing printer (no endstop pins
    exist at all) and a poll that has not landed; "not homed" was a
    guess the live report disproved (homed axes, no pins)."""
    states = snapshot.endstops or {}
    items = []
    for axis in sorted(states):
        raw = str(states[axis]).strip()
        if raw:
            items.append({"name": axis.upper(), "state": raw, "triggered": raw.lower() == "triggered"})
    summary = "" if items or not connected else "No endstop states reported."
    return {"endstopItems": items, "endstopSummary": summary}


def parse_mcu_stats(value):
    source = value if isinstance(value, Mapping) else dict(token.split("=", 1) for token in str(value or "").replace(",", " ").split() if "=" in token)
    return {str(key): number(raw, None) for key, raw in source.items() if number(raw, None) is not None}


def format_bytes(value):
    if value is None or value < 0: return "—"
    if value >= 1000000: return f"{value / 1000000:.2f} MB"
    if value >= 1000: return f"{value / 1000:.1f} kB"
    return f"{value:.0f} B"


def peripheral_values(snapshot):
    temperatures, fans, filament, mcus = [], [], [], []
    cpu, versions = None, []
    chartable = chart_temperature_objects(snapshot.auxiliary)
    for name, value in sorted(snapshot.auxiliary.items()):
        if not isinstance(value, Mapping): continue
        lower, label = name.lower(), chart_label(name)
        if name in chartable:
            temperature = chartable[name]
            target, power = number(value.get("target"), None), number(value.get("power"), None)
            detail = f"{temperature:.1f} °C" + (f"  → {target:.0f} °C" if target is not None else "") + (f"  · {power * 100:.0f}%" if power is not None else "")
            temperatures.append({"name": label, "temperature": temperature, "target": target if target is not None else -1, "power": power if power is not None else -1, "detail": detail})
            if cpu is None and (lower.startswith("temperature_host ") or "cpu" in lower or "rpi" in lower): cpu = temperature
        if "speed" in value and (lower == "fan" or lower.startswith(FAN_OBJECT_PREFIXES)):
            speed = max(0, min(1, number(value.get("speed"))))
            detail = f"{speed * 100:.0f}%" + (f"  · {int(number(value['rpm'])):,} RPM" if value.get("rpm") is not None else "")
            fans.append({"name": label, "speed": speed, "detail": detail})
        if lower.startswith(FILAMENT_OBJECT_PREFIXES):
            detected, enabled = bool(value.get("filament_detected")), bool(value.get("enabled", True))
            filament.append({"name": label, "detected": detected, "enabled": enabled, "state": "Disabled" if not enabled else "Filament detected" if detected else "Runout / not detected"})
        if lower == "mcu" or lower.startswith(MCU_OBJECT_PREFIXES):
            stats = parse_mcu_stats(value.get("last_stats"))
            frequency = stats.get("freq") or number((value.get("mcu_constants") or {}).get("CLOCK_FREQ"), None)
            memory = next((number(value[key], None) for key in ("memory_free", "memavail", "free_memory", "memory") if value.get(key) is not None), None)
            tasks = [f"{label} {stats[key] * 1000000:.1f} µs" for key, label in (("mcu_task_avg", "avg"), ("mcu_task_stddev", "σ")) if key in stats]
            traffic = [label + " " + format_bytes(stats[key]) for key, label in (("bytes_write", "TX"), ("bytes_read", "RX"), ("bytes_retransmit", "retry")) if key in stats]
            version = str(value.get("mcu_version") or "—")
            versions.append(f"{label}: {version}")
            mcus.append({"name": "Main MCU" if lower == "mcu" else label, "version": version,
                "load": f"{max(0, stats['mcu_awake'] * 100):.1f}%" if "mcu_awake" in stats else "—",
                "task": " · ".join(tasks) or "—", "frequency": f"{frequency / 1000000:.3f} MHz" if frequency else "—",
                "memory": format_bytes(memory), "transport": " · ".join(traffic) or "—"})
    system = snapshot.auxiliary.get("system_stats") or {}
    memory = number(system.get("memavail"))
    klippy = str((snapshot.auxiliary.get("webhooks") or {}).get("state") or snapshot.server.get("klippy_state") or "unknown")
    return {"temperatureItems": temperatures, "fanItems": fans, "filamentSensorItems": filament,
        "mcuItems": mcus, "mcuSummary": " · ".join(versions) or "—",
        "hostLoad": f"{number(system.get('sysload')):.2f}" if system.get("sysload") is not None else "—",
        "memoryAvailable": f"{memory / 1048576:.2f} GB" if memory >= 1048576 else f"{memory / 1024:.0f} MB" if memory > 0 else "—",
        "cpuTemperature": f"{cpu:.1f} °C" if cpu is not None else "—", "klippyState": klippy.capitalize(),
        "moonrakerVersion": str(snapshot.server.get("moonraker_version") or "—"),
        "klipperVersion": str(snapshot.printer.get("software_version") or "—")}


def normalise_mesh(raw):
    if not isinstance(raw, (list, tuple)) or len(raw) < 2: return None
    matrix, columns = [], None
    for row in raw:
        if not isinstance(row, (list, tuple)) or len(row) < 2: return None
        if columns is None: columns = len(row)
        if len(row) != columns: return None
        converted = [number(value, None) for value in row]
        if any(value is None for value in converted): return None
        matrix.append(converted)
    return matrix


def parse_bed_mesh(status):
    if not isinstance(status, Mapping): return {}
    matrix, source = normalise_mesh(status.get("mesh_matrix")), "mesh_matrix"
    if matrix is None: matrix, source = normalise_mesh(status.get("probed_matrix")), "probed_matrix"
    if matrix is None: return {}
    minimum, maximum = status.get("mesh_min"), status.get("mesh_max")
    if not isinstance(minimum, (list, tuple)) or not isinstance(maximum, (list, tuple)) or min(len(minimum), len(maximum)) < 2: return {}
    bounds = [number(value, None) for value in (minimum[0], minimum[1], maximum[0], maximum[1])]
    if any(value is None for value in bounds) or bounds[2] <= bounds[0] or bounds[3] <= bounds[1]: return {}
    values = [value for row in matrix for value in row]
    return {"profile": str(status.get("profile_name") or "").strip(), "source": source,
        "rows": len(matrix), "columns": len(matrix[0]), "values": values,
        "xMin": bounds[0], "yMin": bounds[1], "xMax": bounds[2], "yMax": bounds[3],
        "minimum": min(values), "maximum": max(values), "range": max(values) - min(values)}


def mesh_profiles(status):
    if not isinstance(status, Mapping): return []
    raw = status.get("profiles") or ()
    if isinstance(raw, Mapping): names = list(raw)
    else: names = [item if isinstance(item, str) else item.get("name") or item.get("profile") for item in raw if isinstance(item, (str, Mapping))]
    names = sorted({str(name).strip() for name in names if name}, key=str.casefold)
    active = str(status.get("profile_name") or "")
    first = active if active in names else "default" if "default" in names else None
    if first: names.remove(first); names.insert(0, first)
    return names


def literal_default(expression):
    if expression is None: return None, False
    text = expression.strip()
    if text.casefold() in {"true", "false"}: return text.casefold() == "true", True
    if text.casefold() in {"none", "null"}: return "", True
    try: return ast.literal_eval(text), True
    except (SyntaxError, ValueError): return None, False


def infer_macro_parameters(gcode):
    found = {}
    pattern = re.compile(r"params(?:\.([A-Za-z_][A-Za-z0-9_]*)|\[\s*['\"]([^'\"]+)['\"]\s*\])")
    defaults = re.compile(r"\|\s*default\s*\(\s*([^,\)]+)", re.I)
    for line in str(gcode or "").splitlines():
        for match in pattern.finditer(line):
            name = (match.group(1) or match.group(2)).strip().upper()
            tail = line[match.end():]
            default = defaults.search(tail)
            expression = default.group(1).strip() if default else None
            value, literal = literal_default(expression)
            if re.search(r"\|\s*int\b", tail, re.I): kind = "int"
            elif re.search(r"\|\s*float\b", tail, re.I): kind = "float"
            elif isinstance(value, bool): kind = "bool"
            elif isinstance(value, int): kind = "int"
            elif isinstance(value, float): kind = "float"
            elif isinstance(value, str) and value.lower() in {"true", "false"} and re.search(r"\|\s*lower\b", tail, re.I):
                kind, value = "bool", value.lower() == "true"
            else: kind = "string"
            item = {"name": name, "type": kind, "default": str(value) if literal else "", "required": expression is None, "hasDefault": expression is not None}
            if name not in found: found[name] = item
            else:
                old = found[name]
                if old["type"] == "string" and kind != "string": old["type"] = kind
                if not old["hasDefault"] and item["hasDefault"]: old.update(default=item["default"], hasDefault=True, required=False)
    return list(found.values())


# The plate map's object budget: beyond it, rows are dropped and the
# truncation is stated rather than silently ignored.
MAX_PLATE_OBJECTS = 256
# The per-polygon vertex budget: the silhouette is what the map
# draws, and the paint cost is vertices × objects per repaint.
MAX_PLATE_VERTICES = 64
# A bed-coordinate sanity cap: real beds are orders of magnitude below
# this, so anything past it is printer-controlled garbage, not a plate.
_COORD_CAP = 1e7


def _natural_key(name: str):
    """casefolded with numeric runs split, so STL_2 precedes STL_10."""
    return [int(part) if part.isdigit() else part.casefold()
            for part in re.split(r"(\d+)", str(name))]


def _finite_pair(value):
    """A [x, y] pair as finite, sane floats — else None."""
    if isinstance(value, (list, tuple)) and len(value) == 2:
        try:
            x, y = float(value[0]), float(value[1])
            if math.isfinite(x) and math.isfinite(y) and abs(x) < _COORD_CAP and abs(y) < _COORD_CAP:
                return [x, y]
        except (TypeError, ValueError):
            return None
    return None


def containing_object(rows, x, y):
    """The first row whose polygon contains the bed point (ray
    casting) — the local printed-cache's probe (the live ruling: the
    DEFINE order is NOT the print order on every machine, so the
    toolhead's own visits are the truth)."""
    for row in rows:
        polygon = row.get("polygon")
        if polygon and point_in_polygon(x, y, polygon):
            return row["name"]
    return None


def _finite_polygon(value):
    """[[x, y], ...] pairs or a flat [x, y, x, y, ...] run, sanitised:
    any non-finite or absurd coordinate drops the polygon entirely — a
    printer-controlled value must never reach the path builder. The
    ring decimates to the vertex budget: the map needs the silhouette,
    not the raw perimeter's thousands of vertices (the live report —
    full-vertex polygons repainted per poll crawled the picker)."""
    if not isinstance(value, (list, tuple)) or not value:
        return None
    points = []
    if isinstance(value[0], (list, tuple)):
        for point in value:
            pair = _finite_pair(point)
            if pair is None:
                return None
            points.append(pair)
    else:
        if len(value) % 2:
            return None
        for index in range(0, len(value), 2):
            pair = _finite_pair((value[index], value[index + 1]))
            if pair is None:
                return None
            points.append(pair)
    if len(points) < 3:
        return None
    if len(points) <= MAX_PLATE_VERTICES:
        return points
    # Distance decimation over the closed ring; the last vertex is
    # kept so the closing edge always draws.
    perimeter = sum(math.hypot(points[index][0] - points[index - 1][0],
                               points[index][1] - points[index - 1][1])
                    for index in range(1, len(points)))
    stride = perimeter / (MAX_PLATE_VERTICES - 2)
    kept = [points[0]]
    travelled = 0.0
    for index in range(1, len(points) - 1):
        travelled += math.hypot(points[index][0] - points[index - 1][0],
                                points[index][1] - points[index - 1][1])
        if travelled >= stride:
            kept.append(points[index])
            travelled = 0.0
    kept.append(points[-1])
    return kept


def plate_values(exclude_object):
    """The plate map's object projection: normalised polygons in bed
    coordinates, the natural-sort order, and the truncation count. Pure
    and lane-agnostic — the model passes whichever lane carries the
    exclude_object status."""
    exclude_object = exclude_object if isinstance(exclude_object, Mapping) else {}
    excluded = frozenset(exclude_object.get("excluded_objects") or ())
    current = exclude_object.get("current_object")
    objects = []
    truncated = 0
    for index, item in enumerate(exclude_object.get("objects") or ()):
        if not isinstance(item, Mapping) or not item.get("name"):
            continue
        if len(objects) >= MAX_PLATE_OBJECTS:
            truncated += 1
            continue
        name = str(item["name"])
        objects.append({
            "name": name,
            "center": _finite_pair(item.get("center")),
            "polygon": _finite_polygon(item.get("polygon")),
            # The DEFINE order (Klipper prints objects in it, layer by
            # layer — the live-verified order); the passed flag derives
            # from it in the model.
            "order": index,
            "excluded": name in excluded,
            "current": name == current,
        })
    # The natural name sort for the display (the live ruling: the
    # status order read as 1, 10, 11, ..., 2, 20); the `order` field
    # keeps the DEFINE sequence for the printed rule.
    objects.sort(key=lambda row: _natural_key(row["name"]))
    return {"objects": objects, "truncated": truncated, "excludedCount": len(excluded)}


# A job no memo has projected yet. None is a real job value (the
# monitor-only print's unresolved identity), so the fresh state needs
# a sentinel of its own.
_NO_PLATE_JOB = object()


def _plate_points(value):
    """A private copy of a raw point run, in the payload's own container
    shape — the copy is what keeps the later comparison honest (a run
    mutated in place after it was judged must not read as unchanged),
    and matching shapes keep that comparison C-level. A flat run
    (Klipper's own shape) copies in one pass, its elements being
    immutable scalars; only a paired run rebuilds its points."""
    if not isinstance(value, (list, tuple)):
        return value
    if value and isinstance(value[0], (list, tuple)):
        copied = [list(point) if isinstance(point, (list, tuple)) else point
                  for point in value]
        return tuple(copied) if isinstance(value, tuple) else copied
    return tuple(value) if isinstance(value, tuple) else list(value)


def _plate_definition(source):
    """The definition the projection reads, snapshotted away from the
    payload: the object rows in DEFINE order (name, centre, ring), the
    excluded names and the current one. None when the payload's
    `objects` is not a sequence — then it cannot be judged cheaply and
    is projected fresh every poll."""
    objects = source.get("objects") or ()
    if not isinstance(objects, (list, tuple)):
        return None
    rows = []
    for item in objects:
        rows.append((item.get("name"), _plate_points(item.get("center")),
                     _plate_points(item.get("polygon")))
                    if isinstance(item, Mapping) else None)
    return (rows, frozenset(source.get("excluded_objects") or ()),
            source.get("current_object"))


def _canonical_points(value):
    """The run as a tuple of tuples, for the fallback compare — never
    cached, so it may alias the payload."""
    if value and isinstance(value[0], (list, tuple)):
        return tuple(tuple(point) if isinstance(point, (list, tuple)) else point
                     for point in value)
    return tuple(value)


def _same_points(cached, fresh):
    """Point-run equality: the cached side is a private copy in the
    payload's own shape, so the steady state is ONE C-level compare of
    like containers — this compare is the memo's own per-poll cost. A
    payload that flips container types normalises both sides once
    rather than re-walking the ring for a difference that is not
    there."""
    if cached is fresh or cached == fresh:
        return True
    if not isinstance(cached, (list, tuple)) or not isinstance(fresh, (list, tuple)):
        return False
    return _canonical_points(cached) == _canonical_points(fresh)


def _same_definition(saved, source):
    """Whether the payload still carries the definition the cached
    projection was built from. The rings compare as whole runs at C
    speed, so nothing is re-validated per vertex."""
    rows, excluded, current = saved
    if excluded != frozenset(source.get("excluded_objects") or ()) \
            or current != source.get("current_object"):
        return False
    objects = source.get("objects") or ()
    if not isinstance(objects, (list, tuple)) or len(objects) != len(rows):
        return False
    for saved_row, item in zip(rows, objects, strict=True):
        if isinstance(item, Mapping) != (saved_row is not None):
            return False
        if saved_row is None:
            continue
        if saved_row[0] != item.get("name") \
                or not _same_points(saved_row[1], item.get("center")) \
                or not _same_points(saved_row[2], item.get("polygon")):
            return False
    return True


class PlateProjectionMemo:
    """The plate projection, memoised across polls.

    A core poll carries virtual_sdcard's moving file position and
    print_stats' advancing clock; the exclude_object definition rides
    along unchanged, and the session boundary hands out a freshly
    deep-copied status, so object identity can never tell a changed
    definition from a moved one. This judges the DEFINITION instead —
    names, centres, rings and the two flag fields — and reuses the
    normalised rows while it matches, which keeps the per-vertex walk
    (coordinate validation plus ring decimation, O(vertices) of Python
    per object, on the owner thread) off the poll path. A late
    EXCLUDE_OBJECT_DEFINE and a changed silhouette both arrive as a
    changed row, and the job boundary drops a finished print's
    geometry rather than carrying it into the next one.
    """

    def __init__(self):
        self._job = _NO_PLATE_JOB
        self._definition = None
        self._value = None

    def value(self, exclude_object, job=None):
        """The normalised projection for this payload, re-walked only
        when its definition or the job actually changed."""
        source = exclude_object if isinstance(exclude_object, Mapping) else {}
        try:
            unchanged = self._definition is not None and self._value is not None \
                and job == self._job and _same_definition(self._definition, source)
        except Exception:
            # A payload the cheap compare cannot judge (an exotic value
            # type) is projected fresh — exactly what the caller did
            # before the memo existed.
            unchanged = False
        if not unchanged:
            self._value = plate_values(source)
            self._job = job
            self._definition = _plate_definition(source)
        return self._value

