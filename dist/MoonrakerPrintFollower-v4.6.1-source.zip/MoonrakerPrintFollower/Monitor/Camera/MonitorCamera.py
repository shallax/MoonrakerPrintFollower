"""Webcam selection/transform policy with an explicit configuration capability."""
from dataclasses import replace
from math import isfinite
from urllib.parse import urljoin
from PyQt6.QtCore import QObject, QTimer, QUrl, pyqtSignal
from PyQt6.QtNetwork import QHostAddress

from UM.Logger import Logger

from .CameraBridge import CameraBridge
from ...Moonraker.MoonrakerProtocol import same_origin

# The FPS control's bounds. The ceiling is the SELECTED CAMERA's own
# configured target_fps (Moonraker's webcam entry: 5, 15, 30, 60 —
# whatever that installation runs at), never a product constant, so
# MAX_FPS is only the coercion guard for a corrupt record.
MIN_FPS = 0.5
SNAPSHOT_MAX_FPS = 5.0
MAX_FPS = 120.0
# The fallback when the camera reports no usable target_fps (an older
# Moonraker, or a front-end-written entry): the renderer's own idle
# ceiling (MoonrakerMJPGImage.RENDER_INTERVAL_MS = 33 ms — the number
# repeats here because the module-layering pin keeps MonitorCamera
# from importing it).
DEFAULT_MAX_FPS = 30.0


def _clamp_fps(value, fallback):
    """One coercion for every FPS read: hand-edited configs, Moonraker
    payloads and QML wheel deltas all land here."""
    try:
        fps = float(value)
    except (TypeError, ValueError):
        fps = fallback
    if not isfinite(fps):
        fps = fallback
    return max(MIN_FPS, min(MAX_FPS, fps))


class MonitorCamera(QObject):
    changed = pyqtSignal()
    # The webcam watchdog's signals, forwarded from the bridge: a dead
    # stream and its restart. Direct (non-bridge) URLs never emit
    # these — the plugin cannot see a raw stream's health.
    streamFailed = pyqtSignal()
    streamRecovered = pyqtSignal()

    def __init__(self, data, config, apply_config, parent=None):
        super().__init__(parent)
        self._data, self._config, self._apply_config = data, config, apply_config
        self._key = None
        self._camera_signature = None
        self._restore_pending = False
        self._index = -1
        self._values = {}
        self._url = ""
        self._last_url_logged = ""
        self._camera_bridge = None
        # The effective throttle, once published: None until the first
        # selection lands.
        self._fps = None
        data.changed.connect(self.observe)
        self.observe()

    @staticmethod
    def identity(camera, index=0):
        return str(camera.get("uid") or camera.get("id") or camera.get("name") or f"camera-{index}").strip()

    @staticmethod
    def identity_aliases(camera, index=0):
        """Return every stable identifier we can recognise for a webcam.

        New selections are persisted by Moonraker UID when available, but older
        configurations and some Moonraker/front-end integrations may have stored
        a friendly name or an alternate id. Accept those on restore so an upgrade
        does not silently fall back to the first camera.
        """
        values = (camera.get("uid"), camera.get("id"), camera.get("name"), f"camera-{index}")
        return {str(value).strip() for value in values if value is not None and str(value).strip()}

    @staticmethod
    def camera_signature(cameras):
        """Stable projection of list content so unrelated monitor polls do nothing."""
        return tuple(
            (
                MonitorCamera.identity(camera, index),
                str(camera.get("name") or ""),
                str(camera.get("stream_url") or ""),
                str(camera.get("snapshot_url") or ""),
                str(camera.get("rotation") or ""),
                bool(camera.get("flip_horizontal", False)),
                bool(camera.get("flip_vertical", False)),
                # The throttle's ceiling rides the selection: a camera
                # whose target_fps was re-configured re-reads it.
                str(camera.get("target_fps") or ""),
            )
            for index, camera in enumerate(cameras)
        )

    @property
    def values(self): return dict(self._values)
    @property
    def url(self): return self._url

    @staticmethod
    def max_fps(camera):
        """The camera's own configured ceiling: Moonraker's webcam
        entries carry the stream's target_fps (the value its streaming
        service is set to run at), so the control's bar never offers a
        rate the camera cannot send. Entries without one — an older
        Moonraker or a front-end-written record — fall back to the
        renderer's own ceiling."""
        try:
            configured = float((camera or {}).get("target_fps"))
        except (TypeError, ValueError):
            configured = DEFAULT_MAX_FPS
        if not isfinite(configured) or configured <= 0.0:
            configured = DEFAULT_MAX_FPS
        return max(MIN_FPS, min(MAX_FPS, configured))

    def set_fps(self, fps):
        """Persist the rate; crossing 5 FPS switches the camera transport."""
        cameras = self._data.snapshot.webcams
        camera = cameras[self._index] if 0 <= self._index < len(cameras) else {}
        value = min(self.max_fps(camera), _clamp_fps(fps, self._fps or DEFAULT_MAX_FPS))
        if value == self._fps:
            return
        self._apply_config(replace(self._config(), camera_fps=value))
        if self._fps != value:
            self._key = None
            self._restore_selection(self._config(), cameras)

    def observe(self):
        config = self._config()
        cameras = self._data.snapshot.webcams
        signature = self.camera_signature(cameras)

        if signature != self._camera_signature:
            self._camera_signature = signature
            self._key = None
            if cameras:
                # First publish only the model. Qt ComboBox can otherwise try to
                # apply a restored currentIndex while its delegate model is still
                # empty, leaving the control at the wrong item. Restore selection
                # on the next Qt turn, after QML has consumed webcamNames.
                self._restore_pending = True
                self._index = -1
                values = dict(self._values)
                values["webcamNames"] = [str(item.get("name") or f"Camera {i + 1}") for i, item in enumerate(cameras)]
                values["activeWebcamIndex"] = -1
                self._values = values
                self.changed.emit()
                QTimer.singleShot(0, lambda: self._restore_after_population(signature))
                return
            self._restore_pending = False

        if self._restore_pending:
            return
        self._restore_selection(config, cameras)

    def _restore_after_population(self, scheduled_signature=None):
        if not self._restore_pending:
            return
        if scheduled_signature is not None and scheduled_signature != self._camera_signature:
            # The webcam set changed (or the session was invalidated) between
            # scheduling and firing. Keep the restore pending; the next
            # observe() re-schedules against the current snapshot.
            return
        self._restore_pending = False
        self._key = None
        self._restore_selection(self._config(), self._data.snapshot.webcams)

    def _restore_selection(self, config, cameras):
        key = (
            self._camera_signature,
            config.camera_selected,
            config.camera_url,
            config.camera_rotation,
            config.camera_mirror,
            config.url,
            self._data.active,
            config.camera_disabled,
            config.camera_fps,
        )
        if key == self._key:
            return
        self._key = key

        selected = str(config.camera_selected or "").strip()
        remembered = next((i for i, camera in enumerate(cameras) if selected and selected in self.identity_aliases(camera, i)), None)
        if remembered is not None:
            self._index = remembered
        elif cameras:
            self._index = min(max(0, self._index), len(cameras) - 1)
        else:
            self._index = -1

        camera = cameras[self._index] if self._index >= 0 else {}
        maximum = self.max_fps(camera)
        self._fps = min(maximum, _clamp_fps(getattr(config, "camera_fps", DEFAULT_MAX_FPS), DEFAULT_MAX_FPS))
        snapshot = str(camera.get("snapshot_url") or "").strip()
        snapshot_available = bool(snapshot) and self._valid_camera_url(snapshot)
        snapshot_mode = snapshot_available and self._fps <= SNAPSHOT_MAX_FPS
        stream = snapshot if snapshot_mode else str(camera.get("stream_url") or config.camera_url or "")
        # Absolute stream URLs may only be http/https, and
        # protocol-relative inputs ("//host/...") are rejected
        # outright: a hostile Moonraker listing could otherwise point
        # Cura's image loader at an arbitrary host (panel security
        # P3). Plain relative paths — the normal webcam case — pass.
        if stream and not self._valid_camera_url(stream):
            stream = ""
        self._url = urljoin(config.url.rstrip("/") + "/", stream) if stream and self._data.active else ""
        self._url = self._bridge_url(config, self._url)
        if config.camera_disabled:
            # The diagnostics kill-switch: no stream URL, so Cura's
            # loader never fetches — the leak-battery's camera-off
            # condition, without touching the printer.
            self._url = ""
            self._retire_bridge()
        if self._url != self._last_url_logged:
            # The first-load failures were invisible in the logs: the
            # stream decision (direct vs bridged vs none) logs here so
            # a capture names where the loader went.
            self._last_url_logged = self._url
            if self._url:
                parsed = QUrl(self._url)
                shown = f"{parsed.scheme()}://{parsed.host()}" + (f":{parsed.port()}" if parsed.port() > 0 else "") + parsed.path()
                kind = "bridged" if self._camera_bridge is not None and parsed.host() in ("127.0.0.1", "localhost") else "direct"
                Logger.log("i", "Moonraker camera stream: %s (%s)", shown, kind)
                from ...Diagnostics.CameraTiming import mark
                mark("T5-path", "camera transport: %s" % kind)
            else:
                Logger.log("i", "Moonraker camera stream: none")
        try: rotation = int(camera.get("rotation", config.camera_rotation) or 0)
        except (TypeError, ValueError): rotation = 0
        # The throttle is the user's preference CAPPED by the selected
        # camera's own target: switching to a slower camera lowers the
        # effective rate without rewriting the stored preference.
        self._values = {
            "webcamNames": [str(item.get("name") or f"Camera {i + 1}") for i, item in enumerate(cameras)],
            "activeWebcamIndex": self._index,
            "cameraName": str(camera.get("name") or ("Configured camera" if self._url else "")),
            "cameraRotation": rotation if rotation in {0, 90, 180, 270} else 0,
            "cameraFlipHorizontal": bool(camera.get("flip_horizontal", config.camera_mirror)),
            "cameraFlipVertical": bool(camera.get("flip_vertical", False)),
            "cameraFps": self._fps,
            "cameraFpsMin": MIN_FPS,
            "cameraFpsMax": maximum,
            "cameraSnapshotMaxFps": SNAPSHOT_MAX_FPS,
            "cameraSnapshotAvailable": snapshot_available,
            "cameraSnapshotMode": snapshot_mode,
        }
        self.changed.emit()

    @staticmethod
    def _valid_camera_url(value):
        # QUrl strips whitespace; reject protocol-relative and non-web
        # schemes before joining either webcam URL to the Moonraker base.
        parsed = QUrl(value.strip())
        return bool(value.strip()) and parsed.isValid() and not value.strip().startswith("//") \
            and (not parsed.scheme() or parsed.scheme().lower() in ("http", "https"))

    @staticmethod
    def _remote_stream(url):
        parsed = QUrl(url)
        return parsed.scheme().lower() in ("http", "https") and not QHostAddress(parsed.host()).isLoopback()

    def _retire_bridge(self):
        """Stop the bridge but keep the cached object for reuse: a
        deposed camera must hold no live listener and no retained
        credential (the 2026-09-19 review's D)."""
        if self._camera_bridge is not None:
            self._camera_bridge.stop()

    def suspend_stream(self):
        """The stream-off toggle's half (the live request): the bridge
        stops fetching upstream — the bandwidth actually saved — while
        the cached object survives for the re-enable."""
        self._retire_bridge()

    def resume_stream(self):
        """The re-enable's half: rebuild the bridge for the current
        camera. The selection-restore early-outs on an unchanged
        signature — the suspend kept the selection, so the rebuild
        must run regardless: the key is defeated first, and the URL
        is re-derived and re-bridged (the live report: only a camera
        re-select revived the frozen stream)."""
        self._key = None
        self._restore_selection(self._config(), self._data.snapshot.webcams)

    def _bridge_url(self, config, url):
        # A camera behind the header-auth proxy cannot render through
        # Cura's loader (NetworkMJPGImage sends no headers): republish
        # it on the keyless loopback bridge (the 4.0.0
        # ruling). The key travels with the bridge's own upstream
        # fetch; the loader sees a plain local URL. The key NEVER
        # rides to a foreign origin (the 2026-09-19 review's C): an
        # absolute stream on another host is served direct and
        # keyless — and every non-bridged outcome retires the bridge
        # (D), so a deposed or disabled camera leaves no listener
        # behind.
        if not url or not config.api_key or not self._remote_stream(url):
            self._retire_bridge()
            return url
        if not same_origin(config.url, url):
            self._retire_bridge()
            return url
        if self._camera_bridge is None:
            self._camera_bridge = CameraBridge(self)
            # The watchdog's feed-health signals ride the bridge.
            self._camera_bridge.upstreamFailed.connect(self.streamFailed.emit)
            self._camera_bridge.upstreamStarted.connect(self.streamRecovered.emit)
            Logger.log("i", "Moonraker camera bridge created for the key-carrying stream")
        # The upstream is the STREAM'S own origin: an absolute
        # stream_url on another host/port (a separate webcam box) must
        # not be re-homed onto the Moonraker base.
        parsed = QUrl(url)
        upstream = f"{parsed.scheme()}://{parsed.host()}"
        if parsed.port(0) > 0:
            upstream += f":{parsed.port(0)}"
        if not self._camera_bridge.configure(upstream, config.api_key):
            return url
        path = parsed.path() + (("?" + parsed.query()) if parsed.query() else "")
        return self._camera_bridge.local_url(path)

    def select(self, index):
        cameras = self._data.snapshot.webcams
        if not 0 <= index < len(cameras): return
        self._restore_pending = False
        self._index = index
        selected = self.identity(cameras[index], index)
        config = replace(self._config(), camera_selected=selected)
        # apply_config is synchronous; PrinterBinding writes camera-only changes
        # directly to the active machine's settings entry and flushes preferences
        # before this method proceeds.
        self._apply_config(config)
        self._key = None
        self._restore_selection(self._config(), cameras)
