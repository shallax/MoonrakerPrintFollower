"""Active Monitor request/poll lifecycle and immutable data projections."""
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass
from types import MappingProxyType
from collections.abc import Mapping

from PyQt6.QtCore import QObject, QTimer, pyqtSignal
from .Console.ConsolePolicy import MAX_LINE
from .MonitorFormatting import number, preview_block, result, wanted_object
from .MonitorPermissions import Observation
from ..Moonraker.MoonrakerSession import RequestCategory


def freeze(value):
    if isinstance(value, dict): return MappingProxyType({key: freeze(item) for key, item in value.items()})
    if isinstance(value, (list, tuple)): return tuple(freeze(item) for item in value)
    return value


@dataclass(frozen=True)
class MonitorSnapshot:
    core: Mapping
    auxiliary: Mapping
    objects: tuple
    server: Mapping
    printer: Mapping
    power: tuple
    webcams: tuple
    presets: Mapping
    endstops: Mapping


class MonitorData(QObject):
    changed = pyqtSignal()
    invalidated = pyqtSignal()
    # Fired after each auxiliary reply lands in the snapshot — the
    # temperature history feeds from this, not from every publish.
    auxiliaryChanged = pyqtSignal()
    previewBlockChanged = pyqtSignal(dict)
    consoleStoreChanged = pyqtSignal()
    commandChanged = pyqtSignal(object)
    # Fires on every connection-state transition with the new state —
    # the console logs a "#" note on each (the request). Tri-state
    # since 4.2.0: 'unknown' | 'yes' | 'no' (the policy table needs
    # unknown distinguishable from no; the bool monitorConnected
    # projection keeps its old semantics).
    connectionStateChanged = pyqtSignal(str)

    def __init__(self, client, parent=None):
        super().__init__(parent)
        self._client = client
        self._active = False
        # The ownership split (the 4.5.0 multi-printer fix): ownership
        # is the plugin's grant for the SELECTED machine; _active is
        # only the runtime session state. A shared-client reconnect
        # re-arms an OWNED monitor and never a deposed one.
        self._owner_active = False
        self._generation = 0
        self._connection_detail = ""
        # The discovery coalescers (the 2026-09-19 cold-start trace):
        # one in-flight webcam RPC at a time, and one deferred
        # re-discovery timer per boot window — the boot fan-out used
        # to issue the identical request once per caller.
        self._webcams_pending = False
        self._webcams_pending_since = 0.0
        self._discovery_defer_pending = False
        # The observation record (4.2.0): assembled here, with the
        # two closed push-ins for the facts the data owner does not
        # hold — controlsLocked (the model's chrome) and the command
        # lane's busy flag. No-op when unchanged (the A3 contract).
        self._connection_observed = False
        self._controls_locked = False
        self._commands_busy = False
        self._observation = None
        self._timers = {}
        self._console_expanded = False
        self._console_entries = []
        # The store has no cursor API and entries can share a float
        # stamp: dedupe on (time, text) keys instead of the stamp alone.
        # Survives reconnects (not cleared on deactivation) so an entry
        # consumed before a drop never backfills again.
        self._console_seen = deque(maxlen=400)
        self._console_seed = None
        # The error bell's collapsed watch (the live
        # request): the store feed is the only source of error lines,
        # so while the console is collapsed a SLOW poll keeps the
        # bell able to ring — one small request every 5 s, nothing
        # like the expanded cadence.
        self._console_watch = QTimer(self)
        self._console_watch.setInterval(5000)
        self._console_watch.timeout.connect(self._refresh_console_watch)
        self._clear()
        for category, callback in ((RequestCategory.AUXILIARY, self.refresh_aux),
            (RequestCategory.POWER, self.refresh_power), (RequestCategory.SYSTEM, self.refresh_system),
            (RequestCategory.ENDSTOPS, self.refresh_endstops),
            (RequestCategory.CONSOLE, self.refresh_console_store),
            (RequestCategory.DISCOVERY, self.refresh_discovery)):
            timer = QTimer(self)
            timer.timeout.connect(callback)
            self._timers[category] = timer
        self._watchdog = QTimer(self)
        self._watchdog.setSingleShot(True)
        self._watchdog.setInterval(3000)
        self._watchdog.timeout.connect(self._watch_discovery)
        # Use QObject-bound receivers rather than lambdas that capture ``self``.
        # PyQt can automatically disconnect bound QObject receivers when this MonitorData
        # is destroyed; a lambda would outlive the C++ object on the long-lived client.
        client.statusReceived.connect(self.observe)
        client.commandChanged.connect(self.commandChanged.emit)
        client.sessionInvalidated.connect(self._session_invalidated)
        client.connectionChanged.connect(self._connection_changed)

    def _session_invalidated(self):
        # Suspends the RUNTIME only: ownership stays with the selected
        # machine, so the reconnect re-arms it — a revoked ownership
        # here would die forever on the next transport handover.
        self._deactivate_runtime()

    def _connection_changed(self, *args):
        connected = bool(args[0]) if args else self.connected
        if len(args) > 1:
            self._connection_detail = str(args[1])
        # The tri-state latch (4.2.0): a session that has never seen
        # a connection is 'unknown', not 'no' — the policy's
        # fail-closed rows must be able to tell them apart (F10).
        if connected:
            self._connection_observed = True
        # The automatic reconnect must re-arm the monitor: an
        # invalidation deactivated it, and only the MANUAL reconnect
        # paths re-activated it before — a transport handover (or any
        # reconnect) left the model alive but discovery-dead forever
        # (webcams empty, temperatures gone; the harness's suite
        # handover scenario caught it). The re-arm is a no-op when
        # already active — and it is gated on OWNERSHIP: every cached
        # monitor shares this client, so a reconnect after a machine
        # switch must never revive a deposed monitor (the 4.5.0
        # multi-printer fix — the shared reconnect re-activated the
        # old machine's monitor alongside the new one's).
        if connected and self._owner_active and not self._active:
            self._activate_runtime()
        elif connected and self._active:
            # The first data must not wait for the lane timers' next
            # ticks (a live report — aux stayed unpopulated
            # long after the connect): the connection transition
            # itself fires every lane immediately.
            self.refresh_all()
        if connected:
            # The discovery watchdog: on ~30-40% of cold boots the
            # discovery chain never arms (webcams empty, temperatures
            # gone, endstops doubly gated on a system snapshot that
            # also failed to land) and stays dead until a reconnect
            # or a Klippy restart. The healthy chain settles in a
            # couple of seconds, so the check fires 3 s after the
            # connect: still dead, the same re-subscribe the
            # Klippy-ready broadcast uses is issued once.
            self._watchdog.stop()
            self._watchdog.start()
        self._rebuild_observation()
        self.connectionStateChanged.emit(self.connection_state)
        self.changed.emit()

    def _watch_discovery(self):
        # Dead = the objects list never landed or no wanted object
        # produced data; both heal via the discovery re-fire + the
        # subscription re-issue.
        if not self._active or self._client is None:
            return
        snapshot = self._snapshot
        if not getattr(snapshot, "objects", ()) or \
           not any(getattr(snapshot, "auxiliary", {}) or {}):
            self._watchdog.stop()
            self.refresh_discovery()
            self._client.resubscribe()

    @property
    def connection_detail(self):
        return self._connection_detail

    def _clear(self):
        empty = freeze({})
        self._snapshot = MonitorSnapshot(empty, empty, (), empty, empty, (), (), empty, empty)
        # The sentinel: a cleared monitor publishes the explicit
        # absent shape — the strip must never show the previous
        # printer's temps after a switch.
        self.previewBlockChanged.emit(preview_block(
            {}, self._observation, stamp=time.monotonic(), inactive=True,
        ))

    @property
    def snapshot(self): return self._snapshot
    @property
    def active(self): return self._active

    @property
    def connected(self) -> bool:
        return bool(self._client.connected)

    @property
    def connection_state(self) -> str:
        # The tri-state: 'unknown' until the first observed connect
        # of this session generation, then 'yes'/'no'. The bool
        # `connected` above keeps its exact old semantics (unknown
        # reads False, like a fresh session always did) so every
        # legacy reader behaves as before; only the policy table
        # consumes the tri-state.
        if self._client.connected: return "yes"
        return "no" if self._connection_observed else "unknown"

    @property
    def status(self):
        return self._client.status

    def track_command(self, name, expected_states=(), *, timeout_s=10.0):
        self._client.track_command(name, expected_states, timeout_s=timeout_s)

    def accept_command(self, name):
        self._client.accept_command(name)

    def fail_command(self, name, detail):
        self._client.fail_command(name, detail)

    def force_refresh(self):
        self._client.force_refresh()

    def assume_print_stopped(self):
        """The e-stop's assumption rides the client's observation
        layer (the ruling): one point, every consumer."""
        self._client.assume_print_stopped()

    def set_toolhead_guard(self, active):
        self._client.set_toolhead_guard(active)

    def reconnect(self) -> None:
        """The manual Reconnect (a live request, 3.6.0):
        the client cycle of the e-stop recovery, minus the
        connected-only gate — a manual reconnect exists for when the
        UI state is STUCK, which includes being disconnected. It
        re-arms the RUNTIME only, never ownership: a deposed
        monitor's reconnect is a no-op (the 4.5.0 ownership
        close-out — the reconnect action used to re-grant ownership,
        letting a cached stale monitor re-claim the shared client)."""
        if not self._owner_active:
            return
        self._client.stop()
        self._client.start()
        if self._owner_active:
            self._activate_runtime()

    def reconnect_after_emergency(self) -> None:
        """The ruling (2026-09-10, live-proven on a
        printer): after an emergency stop the host refuses commands
        until the connection is cycled. The plugin cycles the client
        once and re-arms the RUNTIME — the emergency path must not
        grant ownership either."""
        if not self._active or not self._client.connected:
            return
        if not self._owner_active:
            return
        self._client.stop()
        self._client.start()
        # The stop invalidated the session and deactivated the
        # monitor; the manual recovery re-arms the runtime.
        if self._owner_active:
            self._activate_runtime()

    def _update(self, **patch):
        from dataclasses import replace
        self._snapshot = replace(self._snapshot, **{key: freeze(value) for key, value in patch.items()})
        self._rebuild_observation()
        self.changed.emit()

    def _rebuild_observation(self):
        core = self._snapshot.core or {}
        aux = self._snapshot.auxiliary or {}
        stats = core.get("print_stats") or {}
        configfile = aux.get("configfile") or {}
        toolhead = aux.get("toolhead") or {}
        objects = getattr(self._snapshot, "objects", ()) or ()
        observation = Observation(
            active=self._active,
            connection=self.connection_state,
            state=str(stats.get("state") or ""),
            homed_axes=str(toolhead.get("homed_axes") or ""),
            assumed_stopped=bool(getattr(self._client, "assumed_stopped", False)),
            save_config_pending=bool(configfile.get("save_config_pending")),
            controls_locked=self._controls_locked,
            busy=self._commands_busy,
            # The authoritative paused bit rides the CORE lane (4.3.0):
            # it arrives with the state word, never one aux interval
            # later. None until the object has been observed.
            is_paused=(core.get("pause_resume") or {}).get("is_paused"),
            # The capability signal: the observed object list is the
            # only proof the pause endpoint exists — an empty list is
            # "not observed yet", an observed list without the module
            # fails the rows closed.
            pause_resume_supported=None if not objects else ("pause_resume" in objects),
        )
        self._observation = observation

    @property
    def observation(self):
        return self._observation

    def set_controls_locked(self, locked):
        """The model's chrome push-in (A3): a no-op when unchanged.
        The emit rides later(0) — a synchronous emit here would
        re-enter consumers mid-gesture (the setter's own publish is
        already running)."""
        locked = bool(locked)
        if locked == self._controls_locked: return
        self._controls_locked = locked
        self._rebuild_observation()
        self.later(0, self.changed.emit)

    def set_commands_busy(self, busy):
        """The command lane's busy push-in (A3): a no-op when
        unchanged. The record updates WITHOUT emitting — every emit
        here re-publishes the whole model, and the toolhead's observe
        re-syncs its Z estimate from the stale snapshot whenever the
        queue holds no Z op: rapid nudge taps walked back to the old
        position between commands (the harness caught it), and a
        synchronous emit re-entered the lane's own queue pump. The
        next core poll (<=1 s) publishes the fresh busy flag; the
        tight per-click gate is actionBusy, which never rode this
        path."""
        busy = bool(busy)
        if busy == self._commands_busy: return
        self._commands_busy = busy
        self._rebuild_observation()

    def set_owner_active(self, active):
        """The plugin's ownership grant — the ONLY writer of
        ownership: this monitor belongs to the selected machine (a
        cached, deposed monitor can never re-acquire it, not even
        through its own reconnect action). The runtime arm follows
        immediately — the arm also builds the initial observation the
        model's first publish reads, so it must not depend on the
        transport state. A reconnect re-arms an OWNED monitor through
        _connection_changed (and a deposed one never)."""
        self._owner_active = bool(active)
        if not active:
            self._deactivate_runtime()
        else:
            self._activate_runtime()

    def _deactivate_runtime(self):
        if not self._active: return
        self._active = False
        self._generation += 1
        # An in-flight reply's callback now dies on the generation
        # guard, so both coalescer gates reopen here — a wedged gate
        # would permanently silence webcam discovery on the next
        # session.
        self._webcams_pending = False
        self._webcams_pending_since = 0.0
        self._discovery_defer_pending = False
        # A fresh session generation has never observed a
        # connection: the tri-state reads 'unknown' again.
        self._connection_observed = False
        for timer in self._timers.values(): timer.stop()
        self._console_watch.stop()
        self._client.transport.cancel_owner("monitor")
        # The console poll state dies with the session so a re-attach
        # is a REAL expand: the backfill seed must re-apply from the
        # persisted stamp (the domain panel's re-seed point — the
        # unchanged-flag early-return once left a rebound session
        # polling without a fresh seed).
        self._console_expanded = False
        self._console_seed = None
        self._console_entries = []
        self._clear()
        # The rebuild runs AFTER the latch reset so the record
        # never holds a stale 'no' while the tri-state already
        # reads 'unknown' (the adversarial round's L7).
        self._rebuild_observation()
        self.invalidated.emit()
        self.changed.emit()

    def _activate_runtime(self):
        if self._active: return
        self._active = True
        from ..Diagnostics.CameraTiming import mark
        mark("T0", "monitor active")
        self._intervals()
        for timer in self._timers.values(): timer.start()
        self.observe(self._client.status)
        self.refresh_all()
        self._rebuild_observation()

    def _intervals(self):
        configured = {
            RequestCategory.CORE: 1000,
            RequestCategory.AUXILIARY: self._client.aux_interval_ms,
            RequestCategory.CONSOLE: self._client.console_interval_ms,
        }
        for category, timer in self._timers.items():
            interval = self._client.session.poll_policy.interval_ms(
                category, configured.get(category, 1000), self._client.session.snapshot.printer_state)
            if timer.interval() != interval: timer.setInterval(interval)

    def request(self, channel, method, path, callback, *, body=None, replace=False, category="auxiliary",
                timeout_ms=5000, rpc=None):
        if not self._active or not self._client.session.base_url: return False
        generation = self._generation
        session = self._client.session.generation
        def finished(payload, error):
            if self._active and generation == self._generation and session == self._client.session.generation:
                callback(payload, error)
        if rpc is not None:
            # The socket RPC lane (the ruling: ditch the HTTP
            # polls) — unavailable means the socket is down or the mode
            # is HTTP, and the same request falls through to the wire.
            rpc_method, rpc_params = rpc
            if self._client.rpc(rpc_method, rpc_params, lambda reply, error: finished(reply, error)):
                return True
            # The bootstrap window: websocket mode with the socket not
            # upgraded yet. Firing HTTP here was the traffic that read
            # as handover cancellations in the log — the lane's own
            # timer retries once the RPC lane is live, so skip the
            # wire instead. The discovery lane's retry is 30 s out —
            # too slow for the boot subscription (the first M117 took
            # that long; the live report) — so a discovery request
            # dropped in this window re-fires the chain after 1 s,
            # when the upgrade has settled on every observed boot.
            if self._client.effective_feed_mode == "websocket":
                if category == RequestCategory.DISCOVERY:
                    # One pending re-arm timer per boot window: the
                    # fan-out used to stack one singleShot per dropped
                    # request, re-firing the whole discovery chain N
                    # times at +1 s. The mark rides the guard so the
                    # trace shows ONE defer per window, not one per
                    # caller.
                    if not self._discovery_defer_pending:
                        from ..Diagnostics.CameraTiming import mark
                        mark("T3-defer", "camera discovery deferred: websocket RPC not ready")
                        self._discovery_defer_pending = True
                        def rearm():
                            self._discovery_defer_pending = False
                            # The deferred webcam request was never
                            # dispatched (this very branch skipped the
                            # wire), so its latch must reopen — the
                            # re-fired chain re-issues it now that the
                            # RPC lane has settled (the 2026-09-19
                            # cold-start trace: the gate otherwise
                            # stayed shut and the camera column read
                            # "no camera" until a manual refresh).
                            self._webcams_pending = False
                            self.refresh_discovery()
                        self.later(1000, rearm)
                return True
        return self._client.transport.send_json("monitor", channel, method, path, finished,
            body=body, replace=replace, category=category, timeout_ms=timeout_ms)

    def later(self, delay_ms, callback):
        generation, session = self._generation, self._client.session.generation
        def run():
            if self._active and generation == self._generation and session == self._client.session.generation:
                callback()
        QTimer.singleShot(delay_ms, run)

    def observe(self, status):
        if not self._active or not isinstance(status, Mapping): return
        status = {name: value for name, value in status.items() if isinstance(value, Mapping)}
        self._intervals()
        self._update(core=dict(status))

    def refresh_all(self):
        if not self._active: return
        self._client.force_refresh()
        # Discovery first: the HTTP aux query is built from the
        # objects list, so a connect-transition aux fires with the
        # freshest objects when they already exist.
        self.refresh_discovery()
        self.refresh_aux()
        self.refresh_power()
        self.refresh_system()
        self.refresh_endstops()
        self.refresh_webcams()

    @property
    def console_entries(self) -> list:
        return list(self._console_entries)

    @staticmethod
    def wants_object(name):
        return wanted_object(name)

    def refresh_discovery(self):
        self.request("objects", "GET", "printer/objects/list", self._objects, category="discovery", rpc=("printer.objects.list", {}))
        self.request("presets", "GET", "server/database/item?namespace=mainsail&key=presets",
            lambda payload, error: self._update(presets=result(payload).get("value", {})) if not error and isinstance(result(payload), Mapping) else None,
            category="discovery",
            rpc=("server.database.get_item", {"namespace": "mainsail", "key": "presets"}))
        # The webcam list rides the discovery cycle too: it previously
        # fired ONLY in the once-per-connect refresh_all, and when the
        # RPC lane had not upgraded yet that one request was dropped
        # forever — the camera stayed unselected until a manual
        # refresh (the live report; the harness's scenario 4
        # caught it).
        self.refresh_webcams()

    def _objects(self, payload, error):
        value = result(payload)
        names = value.get("objects") if isinstance(value, Mapping) else None
        if error or not isinstance(names, (tuple, list)): return
        self._update(objects=tuple(sorted(str(name) for name in names)))
        self._reconcile_aux_subscription()
        if "configfile" in names:
            self.request("config-static", "POST", "printer/objects/query", self._aux,
                body={"objects": {"configfile": None}}, replace=True, category="discovery",
                rpc=("printer.objects.query", {"objects": {"configfile": None}}))
        self.refresh_aux()

    def _reconcile_aux_subscription(self):
        """The wanted set must reach the socket even before any aux data
        has arrived: Moonraker only pushes subscribed objects, so waiting
        for the first fragment to issue the subscription is a deadlock
        — temperatures never appeared in websocket mode (the
        live report)."""
        if self._client.effective_feed_mode != "websocket":
            return
        wanted = {name for name in self._snapshot.objects if self.wants_object(name)}
        self._client.set_auxiliary_objects(wanted)

    def refresh_aux(self):
        if not self._snapshot.objects:
            # The boot-time RPC window drops the discovery request and
            # nothing re-fires it until the 30 s discovery tick — the
            # first M117 took that long to appear (the live report).
            # The aux tick is the fastest healthy cadence: re-arm the
            # discovery here so the subscription heals within one aux
            # interval. The coalescer bounds the in-flight duplicates.
            self.refresh_discovery()
            return
        if self._client.effective_feed_mode == "websocket":
            # The socket is a source, not a clock (A11): the existing
            # auxiliary timer drains the accumulated fragments.
            patch, _stamp = self._client.drain_aux()
            if patch:
                self._merge_aux(patch)
            else:
                self._reconcile_aux_subscription()
            return
        objects = {name: ["save_config_pending", "save_config_pending_items"] if name == "configfile" else None
                   for name in self._snapshot.objects if self.wants_object(name)}
        if objects: self.request("aux", "POST", "printer/objects/query", self._aux, body={"objects": objects})

    def _aux(self, payload, error):
        value = result(payload)
        incoming = value.get("status") if isinstance(value, Mapping) else None
        if error or not isinstance(incoming, Mapping): return
        self._merge_aux(incoming)

    def _merge_aux(self, incoming):
        # Rebuild from the current wanted set so objects that were renamed or
        # hot-removed stop rendering instead of staying in the snapshot for
        # the rest of the session. Newly-seen objects join the set even when
        # the first objects/list missed them — a device switched on
        # mid-print must show up, not be dropped (the rule).
        wanted = {name for name in self._snapshot.objects if self.wants_object(name)}
        wanted |= {name for name in incoming if self.wants_object(name)}
        # The wanted set is the subscription's declarative input (A8/F5):
        # a membership change re-issues the one merged subscription.
        self._client.set_auxiliary_objects(wanted)
        merged = {name: state for name, state in self._snapshot.auxiliary.items() if name in wanted}
        for name, value in incoming.items():
            if name not in wanted: continue
            previous = merged.get(name)
            merged[name] = dict(previous, **value) if isinstance(previous, Mapping) and isinstance(value, Mapping) else value
        # Built pre-frozen so freeze() passes it through untouched:
        # unchanged names keep their identity across ticks and the
        # model's identity-keyed payload caches can actually hit (the
        # review's finding: the unconditional re-freeze rebuilt every
        # level every tick, so those caches could never hit).
        merged = MappingProxyType({name: freeze(state) for name, state in merged.items()})
        self._update(auxiliary=merged)
        self.auxiliaryChanged.emit()
        # The Preview value block rides the aux clock: the stamp is
        # taken HERE, at the landing — the coordinator never
        # re-stamps a block in transit (the seam's staleness rule).
        self.previewBlockChanged.emit(preview_block(
            self._snapshot.auxiliary, self._observation,
            stamp=time.monotonic(), inactive=not self._active,
        ))

    # The console's gcode-store feed: polled ONLY while the console is
    # expanded (the ruling), on the CONSOLE poll interval with
    # an idle floor (PollPolicy). The store holds Klipper's output
    # VERBATIM — Moonraker strips nothing (data_store.py stores the
    # payload as delivered) — and modern Klipper's response lines carry
    # no "ok" prefix at all (the "ok" is the RPC result, never console
    # output), so the store can never attest success. The honest proxy:
    # a line that is neither "!!" nor an "//" echo is normal output.
    def set_console_expanded(self, expanded, stored_time=0.0):
        expanded = bool(expanded)
        if expanded == self._console_expanded:
            # Started collapsed: the transition never happened, but
            # the bell's watch still needs to run.
            if not expanded and not self._console_watch.isActive():
                self._console_watch.start()
            return
        self._console_expanded = expanded
        if expanded:
            # The persisted last-seen stamp seeds the ONE-SHOT skip on
            # the first fetch: the store's buffer holds entries from
            # other sessions and other clients, and re-adding them was
            # the "stale responses without requests" dump.
            self._console_seed = float(stored_time or 0.0)
            self._console_watch.stop()
            self.refresh_console_store()
        else:
            self._console_watch.start()

    def _refresh_console_watch(self):
        """The collapsed console's slow poll — the error bell's feed."""
        if not self._active or self._console_expanded:
            return
        self.refresh_console_store(force=True)

    def refresh_console_store(self, force=False):
        if not self._console_expanded and not force:
            return
        def finished(payload, error):
            if error or not isinstance(result(payload), Mapping):
                return
            store = result(payload).get("gcode_store")
            if not isinstance(store, (list, tuple)):
                return
            seed = self._console_seed
            self._console_seed = None
            seen = self._console_seen
            responses = []
            for entry in store:
                if not isinstance(entry, Mapping) or entry.get("type") != "response":
                    continue
                stamp = number(entry.get("time"), float) or 0.0
                text = str(entry.get("message") or "")
                if not text:
                    continue
                if (stamp, text) in seen:
                    continue
                if seed is not None and stamp <= seed:
                    # The seed protects only this FIRST fetch — but the
                    # entries it skips must stay skipped for the whole
                    # session, or the next poll re-delivers the stale
                    # buffer (the live report: the console
                    # re-fetching Moonraker's history on load).
                    seen.append((stamp, text))
                    continue
                seen.append((stamp, text))
                if "resume aborted" in text.lower():
                    # Klipper's no-op verdict on a RESUME with nothing
                    # paused (CLEAR_PAUSE leaves the state proxy
                    # reading "paused" forever): settle the tracked
                    # Resume immediately as a benign terminal — the
                    # 300 s window is for a slow re-heat, never for a
                    # command the printer has already refused.
                    self._client.settle_command("Resume", "Nothing to resume")
                responses.append({
                    "text": text[:MAX_LINE],
                    "error": text.startswith("!!"),
                    "success": not text.startswith("!!") and not text.startswith("//"),
                    "time": stamp,
                })
            if responses:
                self._console_entries = responses
                self.consoleStoreChanged.emit()
        self.request("console-store", "GET", "server/gcode_store?count=100", finished, category="console", rpc=("server.gcode_store", {"count": 100}))

    def refresh_endstops(self):
        # Endstop pin states are NOT part of the objects query; the
        # only live readout is this one-shot status endpoint, polled on
        # a slow cadence (they change at homing, not every second).
        # The poll waits for Klippy to report ready: during a
        # firmware/restart every request lands in the gcode store as
        # "!! Internal Error on WebRequest" (the live report
        # — Moonraker starts fine, the plugin was just noisy about
        # it), and an unanswered readiness check must not paint the
        # console red.
        if (self._snapshot.server or {}).get("klippy_state") != "ready":
            return
        # NEVER while a print runs: query_endstops makes Klipper
        # briefly pause the toolhead while it answers — a 250-500 ms
        # dwell at the poll's 10 s cadence on the live
        # print (quitting Cura stopped it). The endstop states cannot
        # change mid-print, so the poll resumes only once idle.
        state = (self._snapshot.core.get("print_stats") or {}).get("state")
        if state in ("printing", "paused"):
            return
        # A failed poll must never erase last-known states: an empty
        # endstop map reads as "not homed yet" while connected, which is
        # a lie about the printer during a transient network blip. The
        # states blank only on invalidation/disconnect.
        self.request("endstops", "GET", "printer/query_endstops/status",
            lambda p, e: self._update(endstops=dict(result(p))) if not e and isinstance(result(p), Mapping) else None,
            category="endstops",
            rpc=("printer.query_endstops.status", {}))

    def refresh_power(self):
        self.request("power-list", "GET", "machine/device_power/devices",
            lambda p, e: self._update(power=result(p).get("devices", ())) if not e and isinstance(result(p), Mapping) else None,
            category="power",
            rpc=("machine.device_power.devices", {}))

    def refresh_system(self):
        for channel, path, key in (("server-info", "server/info", "server"), ("printer-info", "printer/info", "printer")):
            self.request(channel, "GET", path,
                lambda p, e, k=key: self._update(**{k: result(p)}) if not e and isinstance(result(p), Mapping) else None,
                category="system",
                rpc=("server.info" if key == "server" else "printer.info", {}))

    def refresh_webcams(self):
        # Same retention principle as endstops: a failed poll must never
        # erase last-known cameras — a transient blip would blank the
        # camera column ("no camera") during a printer reboot. The list
        # clears only on invalidation/disconnect.
        # In-flight coalescing (the 2026-09-19 cold-start trace): the
        # boot fan-out called this once per caller, issuing the
        # identical RPC many times a cycle. One request at a time;
        # every caller observes the same landed answer through the
        # snapshot (the reply lands in _update -> data.changed). The
        # 10 s valve keeps a DROPPED reply (a session-generation
        # guard can swallow the callback) from wedging the gate shut:
        # discovery must never go silent for longer than a poll.
        if self._webcams_pending:
            if time.monotonic() - self._webcams_pending_since < 10.0:
                return
        self._webcams_pending = True
        self._webcams_pending_since = time.monotonic()
        from ..Diagnostics.CameraTiming import mark_once
        # Once per trace: the T0-T9 chain answers the COLD start, and
        # the periodic discovery poll would otherwise re-mark every
        # 30 s for the session's lifetime.
        mark_once("T3", "webcam list requested")
        def landed(payload, error):
            # Cleared FIRST: a dropped callback (the generation guard
            # in request()) must never wedge the gate shut. The
            # deactivate path resets it too, for the same reason.
            self._webcams_pending = False
            if not error and isinstance(result(payload), Mapping):
                mark_once("T4", "webcam list landed")
                self._update(webcams=tuple(item for item in result(payload).get("webcams", ()) if isinstance(item, dict) and item.get("enabled", True)))
        if not self.request("webcams", "GET", "server/webcams/list", landed,
                replace=True, category="discovery",
                rpc=("server.webcams.list", {})):
            self._webcams_pending = False


