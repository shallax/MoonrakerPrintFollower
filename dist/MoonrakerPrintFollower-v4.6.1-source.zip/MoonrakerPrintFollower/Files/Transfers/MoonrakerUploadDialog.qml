import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.3
import UM 1.5 as UM
import Cura 1.1 as Cura

UM.Dialog {
    id: base
    title: "Upload to Moonraker"

    property real dialogMargin: UM.Theme.getSize("default_margin").width
    minimumWidth: 520 * screenScaleFactor
    minimumHeight: Math.max(340 * screenScaleFactor, form.implicitHeight + 2 * dialogMargin)
    width: minimumWidth
    height: minimumHeight

    // Cura.ComboBox expects a catalog in the creation context.  Supplying it here
    // avoids the undefined-catalog QML error seen in Cura 5.13's upload dialog.
    property variant catalog: UM.I18nCatalog {
        name: "cura"
    }
    property string forbiddenCharacters: ":*?\"<>|"

    function validFilename(value) {
        var name = value.trim();
        if (name.length === 0 || name === "." || name === "..")
            return false;
        for (var i = 0; i < forbiddenCharacters.length; ++i) {
            if (name.indexOf(forbiddenCharacters.charAt(i)) !== -1)
                return false;
        }
        return true;
    }

    function validPath(value) {
        var path = value.trim();
        if (path === "<root>")
            return true;
        if (path === "." || path === "..")
            return false;
        for (var i = 0; i < forbiddenCharacters.length; ++i) {
            if (path.indexOf(forbiddenCharacters.charAt(i)) !== -1)
                return false;
        }
        return true;
    }

    onRejected: manager.cancelUpload()

    // The dialog's own machinery accepts on Enter (UM's Dialog root
    // does Keys.onReturnPressed: base.accept()); fighting the key
    // routing loses when the focused field consumes the key. Resolve
    // through the dialog's own accepted signal instead — whatever
    // accepted it (the button, Enter, the platform) takes the SAME
    // path. The unresolved-close wedge is healed controller-side
    // (begin() resets a stale choice), so no cancel-on-close here:
    // that fired on the open itself in real Cura and deleted the
    // dialog before it could show.
    onAccepted: {
        manager.acceptUpload(pathField.editText, filenameField.text, printField.checked);
    }

    ColumnLayout {
        id: form
        anchors.fill: parent
        anchors.margins: base.dialogMargin
        spacing: UM.Theme.getSize("default_margin").height

        UM.Label {
            text: "Remote folder"
            font: UM.Theme.getFont("medium_bold")
        }

        Cura.ComboBox {
            id: pathField
            Layout.fillWidth: true
            Layout.minimumWidth: 360 * screenScaleFactor
            editable: true
            model: manager.uploadPathOptions
            Component.onCompleted: {
                var index = find(manager.initialUploadPath);
                if (index >= 0)
                    currentIndex = index;
                editText = manager.initialUploadPath;
            }
        }

        UM.Label {
            text: "<root> is Moonraker's gcodes directory. Other folders are discovered from the printer, or you can type a path."
            color: UM.Theme.getColor("text_inactive")
            font: UM.Theme.getFont("default_italic")
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
        }

        UM.Label {
            visible: !base.validPath(pathField.editText)
            text: "The remote folder contains characters Moonraker cannot use."
            color: UM.Theme.getColor("error")
            font: UM.Theme.getFont("default_italic")
        }

        UM.Label {
            text: "Filename"
            font: UM.Theme.getFont("medium_bold")
        }

        Cura.TextField {
            id: filenameField
            Layout.fillWidth: true
            text: manager.initialUploadFilename
            maximumLength: 1024
            selectByMouse: true
        }

        UM.Label {
            visible: !base.validFilename(filenameField.text)
            text: "Enter a valid filename. Characters : * ? \" < > | are not allowed."
            color: UM.Theme.getColor("error")
            font: UM.Theme.getFont("default_italic")
        }

        UM.CheckBox {
            id: printField
            text: "Start printing after upload"
            checked: manager.initialStartPrint
        }

        Item {
            Layout.fillHeight: true
        }

        RowLayout {
            Layout.fillWidth: true
            layoutDirection: Qt.RightToLeft
            spacing: UM.Theme.getSize("default_margin").width

            Cura.PrimaryButton {
                text: printField.checked ? "Upload and print" : "Upload"
                enabled: base.validFilename(filenameField.text) && base.validPath(pathField.editText)
                onClicked: base.accept()
            }

            Cura.SecondaryButton {
                text: "Cancel"
                onClicked: base.reject()
            }
        }
    }
}
