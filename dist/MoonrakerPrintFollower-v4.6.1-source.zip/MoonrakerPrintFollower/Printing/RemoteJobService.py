from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Optional, Tuple


JobKey = Tuple[str, int, int]


@dataclass(frozen=True)
class PrintObservation:
    state: str
    filename: str
    file_size: int
    file_position: int
    print_duration: float


@dataclass(frozen=True)
class PrintTransition:
    key: Optional[JobKey]
    new_job: bool
    serial: int


@dataclass
class RemoteJobState:
    key: Optional[JobKey] = None
    serial: int = 0
    observation: Optional[PrintObservation] = None
    carried_position: Optional[int] = None


class RemoteJobService:
    """Own remote print observation, run identity and same-file restart detection."""

    def __init__(self, active_states: Iterable[str]) -> None:
        self._active_states = {str(item) for item in active_states}
        self._state = RemoteJobState()

    @property
    def key(self) -> Optional[JobKey]:
        return self._state.key

    @property
    def serial(self) -> int:
        return self._state.serial

    @property
    def observation(self) -> Optional[PrintObservation]:
        return self._state.observation

    @property
    def printer_state(self) -> str:
        observation = self._state.observation
        return observation.state if observation is not None else ""

    @property
    def filename(self) -> str:
        observation = self._state.observation
        return observation.filename if observation is not None else ""

    def current_job_matches(self, history_payload, job_id) -> Optional[bool]:
        """The metadata latch's cross-check (4.3.0): the payload can
        only PROVE the job is current, never that it is not — an
        unattestable reply (a transport failure, an empty history, a
        malformed payload) returns None, not False. The caller's
        give-up policy decides what None means."""
        try:
            jobs = ((history_payload or {}).get("result") or {}).get("jobs") or []
            if not jobs:
                # An empty history is UNATTESTABLE, not a mismatch: a
                # False here lands in the caller's permanent-refusal
                # branch, and a check that can never pass is silent
                # and permanent (the contract this docstring states).
                return None
            return str(jobs[0].get("job_id")) == str(job_id)
        except (AttributeError, TypeError):
            return None

    def observe(
        self,
        print_stats: Dict[str, Any],
        virtual_sdcard: Dict[str, Any],
    ) -> PrintTransition:
        state = str(print_stats.get("state") or "")
        filename = str(print_stats.get("filename") or "")
        try:
            file_size = int(virtual_sdcard.get("file_size") or 0)
        except (TypeError, ValueError):
            file_size = 0
        try:
            file_position = int(virtual_sdcard.get("file_position") or 0)
        except (TypeError, ValueError):
            file_position = 0
        try:
            print_duration = float(print_stats.get("print_duration") or 0.0)
        except (TypeError, ValueError):
            print_duration = 0.0

        observation = PrintObservation(
            state, filename, file_size, file_position, print_duration
        )
        carried = self._state.carried_position
        if carried is not None and observation.file_position != carried:
            # The print has read bytes of its own: the value the
            # boundary carried over is spent, once and for all.
            self._state.carried_position = None
        previous = self._state.observation
        active = observation.state in self._active_states and bool(observation.filename)
        new_job = False
        if active:
            key = self._state.key
            if key is None:
                new_job = True
            elif key[0] != observation.filename:
                new_job = True
            elif key[1] > 0 and observation.file_size > 0 and key[1] != observation.file_size:
                # An unknown size on either side must not churn the run
                # identity: a poll that transiently lacks virtual_sdcard
                # (reconnect, restart, truncated response) would otherwise
                # restart Preview tracking, pause schedules and downloads.
                new_job = True
            elif previous is None or previous.state not in self._active_states:
                new_job = True
            elif observation.state == previous.state == "printing" and observation.file_position > 0 and previous.file_position > 0 and observation.file_position < previous.file_position:
                new_job = True
            elif observation.print_duration + 0.05 < previous.print_duration:
                new_job = True

            if new_job:
                self._state.serial += 1
                self._state.key = (
                    observation.filename,
                    observation.file_size,
                    self._state.serial,
                )
                # The byte offset the finished print left standing. It
                # survives a stop (virtual_sdcard holds it until the
                # next file read), so the new job's first polls can
                # report it — see position_attributed.
                self._state.carried_position = (
                    previous.file_position if previous is not None else None
                )

        self._state.observation = observation
        return PrintTransition(self._state.key, new_job, self._state.serial)

    def position_attributed(self, position: int) -> bool:
        """Whether *position* is the current job's own reading.

        A new job's first polls can still report the offset the
        previous print ended on; crediting it painted the restarted
        print's first layer with the finished print's fraction. That
        value stays refused until the printer replaces it — same file
        or not, it is not this print's evidence.
        """
        carried = self._state.carried_position
        return carried is None or int(position) != carried

    def reset(self) -> None:
        self._state = RemoteJobState()
