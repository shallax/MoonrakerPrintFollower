"""Cura output-device adapter. Upload policy and file preparation are composed."""

from dataclasses import replace

from PyQt6.QtCore import QUrl, QVariant, pyqtProperty, pyqtSignal, pyqtSlot
from PyQt6.QtGui import QDesktopServices
from cura.PrinterOutput.Models.PrinterOutputModel import PrinterOutputModel
from cura.PrinterOutput.PrinterOutputController import PrinterOutputController
from cura.PrinterOutput.PrinterOutputDevice import ConnectionType, PrinterOutputDevice
from UM.Logger import Logger
from UM.Message import Message
from UM.OutputDevice import OutputDeviceError

from .CuraOutputWriter import CuraOutputWriter
from ..Files.Transfers.UploadController import UploadController

from ..Resources.PluginPaths import plugin_path


class MoonrakerOutputController(PrinterOutputController):
    def __init__(self, output_device):
        super().__init__(output_device)
        self.can_pause = self.can_abort = False
        self.can_pre_heat_bed = self.can_pre_heat_hotends = False
        self.can_send_raw_gcode = self.can_control_manually = False
        self.can_update_firmware = False


class MoonrakerOutputDevice(PrinterOutputDevice):
    DEVICE_PREFIX = "MoonrakerPrintFollower@"
    uploadPathsChanged = pyqtSignal()

    def _print_verdict(self):
        from ..Monitor.MonitorPermissions import can_start_print
        monitor = getattr(self, "activePrinter", None)
        data = getattr(monitor, "_data", None)
        observation = getattr(data, "observation", None) if data is not None else None
        if observation is None:
            return None  # the legacy path: no monitor, no gate
        return can_start_print(observation)

    def __init__(self, application, machine_id, *, client, config, apply_config, active_identity, has_slice=None):
        super().__init__(device_id=self.DEVICE_PREFIX + machine_id, connection_type=ConnectionType.NetworkConnection)
        self._application, self._config, self._apply_config = application, config, apply_config
        self._has_slice = has_slice
        self._writer = CuraOutputWriter(application)
        self._upload = UploadController(client, machine_id, active_identity, self)
        # The upload-with-start dispatch gate (4.2.0, the security
        # re-review's D4): the policy's can_start_print, read from
        # the installed monitor when one exists — a missing
        # observation allows (the upload-and-print flow must work
        # without the Monitor page ever opened).
        self._upload.set_print_gate(self._print_verdict)
        self._dialog = self._message = None
        self._monitor_view_qml_path = None
        self._upload.changed.connect(self.uploadPathsChanged.emit)
        self._upload.dialogClosed.connect(self._release_dialog)
        self._upload.choicesAccepted.connect(self._remember)
        self._upload.status.connect(self._status)
        self._upload.progress.connect(self._progress)
        self._upload.finished.connect(self._finished)
        stack = application.getGlobalContainerStack()
        try: extruders = int(stack.getProperty("machine_extruder_count", "value"))
        except Exception: extruders = 1
        self._printers = [PrinterOutputModel(MoonrakerOutputController(self), extruders)]
        self.updateConfig(active_identity)

    @pyqtSlot()
    def leaveMonitorStage(self):
        """Esc on the Monitor page leaves it (the live
        request): back to the Preview stage when anything is sliced,
        otherwise to Prepare."""
        try:
            sliced = self._has_slice is not None and bool(self._has_slice())
            self._application.getController().setActiveStage("PreviewStage" if sliced else "PrepareStage")
        except Exception:
            Logger.log("w", "Moonraker: could not leave the monitor stage")
        # The console's expanded lifecycle (the reviewer's 2026-09-17
        # finding): Cura caches the monitor item after the user
        # leaves, and its Connections keep consoleSyncLines() driving
        # a hidden document. Collapsing on exit stops the gcode-store
        # poll through the existing collapse gate; re-entry seeds
        # from the persisted (collapsed) map.
        monitor = getattr(self, "activePrinter", None)
        if monitor is not None:
            try:
                monitor.setConsoleExpanded(False)
            except Exception:
                Logger.log("w", "Moonraker: could not reset the console expansion on stage exit")

    def updateConfig(self, identity):
        """Set the device's display name from its binding identity.

        The name comes from the machine this device was created for —
        never the application's current global stack, which a machine
        switch or a reordered refresh could change independently.
        """
        try:
            _machine_id, name = identity()
        except Exception:
            name = "Printer"
        self.setName(name)
        self.setDescription("Upload to " + name)
        self.setShortDescription("Upload to " + name)
        self.setIconName("print")
        self.setConnectionText("Connected via Moonraker")
        self.setPriority(5)

    @pyqtProperty(str, notify=uploadPathsChanged)
    def initialUploadPath(self): return self._upload.path or "<root>"

    def setMonitorViewQmlPath(self, path: str) -> None:
        """Explicit capability the output plugin supplies for the Monitor panel."""
        self._monitor_view_qml_path = str(path or "")
    @pyqtProperty(str, notify=uploadPathsChanged)
    def initialUploadFilename(self): return self._upload.filename
    @pyqtProperty(bool, notify=uploadPathsChanged)
    def initialStartPrint(self): return bool(self._upload.start_print)
    @pyqtProperty(QVariant, notify=uploadPathsChanged)
    def uploadPathOptions(self): return QVariant(self._upload.paths)

    def requestWrite(self, node, fileName=None, *args, **kwargs):
        if self._upload.busy:
            # The Enter wedge: a dialog dismissed without resolving its
            # choice leaves the controller active with a dead dialog —
            # busy forever, so the dialog never re-opens (the
            # live report). A closed-but-unresolved dialog resets here;
            # a genuinely busy transfer still refuses.
            if self._dialog is not None:
                try:
                    if not bool(self._dialog.isVisible()):
                        self._upload.cancel()
                        self._release_dialog()
                except RuntimeError:
                    pass
        if self._upload.busy: raise OutputDeviceError.DeviceBusyError()
        config = self._config()
        try:
            self._upload.begin(config, fileName or "print")
        except (ValueError, RuntimeError) as error:
            self._error(str(error))
            return
        self.writeStarted.emit(self)
        try:
            self._upload.prepared(self._writer.prepare(config, fileName))
            if config.upload_dialog:
                try:
                    path = plugin_path("Files", "Transfers", "MoonrakerUploadDialog.qml")
                    self._dialog = self._application.createQmlComponent(path, {"manager": self})
                    self._dialog.show()
                    self._upload.discover()
                except Exception:
                    self._release_dialog()
                    self._upload.start()
            else:
                self._upload.start()
        except Exception as error:
            self._upload.fail("Could not prepare the Moonraker upload: " + str(error))

    @pyqtSlot(str, str, bool)
    def acceptUpload(self, path, filename, start_print): self._upload.accept(path, filename, start_print)
    @pyqtSlot()
    def cancelUpload(self): self._upload.cancel()
    def deactivate(self): self._upload.abort()

    def _remember(self, path, start_print):
        try:
            config = self._config()
            paths = list(config.upload_paths)
            if path and path not in paths: paths.append(path)
            updated = replace(config, upload_paths=paths)
            if config.upload_remember_state: updated = replace(updated, upload_path=path, upload_start_print=start_print)
            self._apply_config(updated)
        except Exception as error:
            # Remembering convenience choices must never block the actual upload.
            Logger.log("w", "Moonraker Print Follower: could not remember upload choices: %s", error)

    def _release_dialog(self):
        dialog, self._dialog = self._dialog, None
        if dialog is not None:
            try: dialog.deleteLater()
            except RuntimeError: pass

    def _status(self, text):
        if self._message is None:
            self._message = Message(text, 0, False)
            self._message.setTitle("Moonraker")
            self._message.show()
        else: self._message.setText(text)

    def _progress(self, percent):
        if self._message is not None: self._message.setProgress(percent)
        self.writeProgress.emit(self, percent)

    def _error(self, text):
        message = Message(text, 0, False)
        message.setTitle("Moonraker - Error")
        message.show()

    def _finished(self, success, error):
        try:
            if self._message is not None:
                self._message.hide()
                self._message = None
            if success:
                config = self._upload.config
                suffix = {"started": " and started the print", "queued": " and queued the print"}.get(
                    self._upload.print_outcome, "")
                self._message = Message(f"Uploaded '{self._upload.filename}' to {self.getName()}{suffix}.", 30 if config.upload_autohide_message else 0, True)
                self._message.setTitle("Moonraker")
                self._message.addAction("open_browser", "Open Browser", "globe", "Open the configured Moonraker frontend")
                # Uranium's Signal stores plain functions weakly — a
                # lambda here is collected before the click and the
                # button lands on nothing (the live report). A bound
                # method on this long-lived device survives; the target
                # is captured because a later upload replaces the
                # upload object before the button is clicked.
                self._browser_target = config.frontend_target
                self._message.actionTriggered.connect(self._on_message_action)
                self._message.show()
                self.writeSuccess.emit(self)
            elif error:
                self._error(error)
                self.writeError.emit(self)
        finally:
            self._upload.terminal_delivered()
            self.writeFinished.emit(self)

    def _on_message_action(self, message, action):
        if action != "open_browser":
            return
        try:
            target = getattr(self, "_browser_target", "") or self._upload.config.frontend_target
            if not QDesktopServices.openUrl(QUrl(target)):
                Logger.log("w", "Moonraker Print Follower: could not open the browser for %s", target)
        except Exception as error:
            Logger.log("w", "Moonraker Print Follower: could not open the browser: %s", error)
